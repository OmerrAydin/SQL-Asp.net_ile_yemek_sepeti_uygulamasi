﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace yemek_sepeti
{
    public partial class AnasayfaGiris : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isCustomer"]) == true) //Müşteri ise girebilir.
            {

            }
            else
            {
                Response.Redirect("Giris_Yap.aspx");
            }


        }
    }
}