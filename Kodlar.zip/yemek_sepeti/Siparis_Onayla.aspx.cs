﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class Siparis_Onayla : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isDealer"])) //Giris Yapan satıcı mı kontrol ediyoruz
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_SiparisleriGetir = new SqlCommand("up_SiparişleriGetirSaticiyaGore @Ponay,@PsaticiKullaniciAdi", baglanti); //Onaylanmamış siparişleri getirir.
                sqlCommand_SiparisleriGetir.Parameters.AddWithValue("@PsaticiKullaniciAdi", Convert.ToString(Session["Nickname"]));
                sqlCommand_SiparisleriGetir.Parameters.AddWithValue("@Ponay", false);
                SqlDataReader okuyucu = sqlCommand_SiparisleriGetir.ExecuteReader();
                DataList1.DataSource = okuyucu;
                DataList1.DataBind(); //Verileri eşler.
                okuyucu.Close();
                baglanti.Close();
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //Satıcı değilse giriş yapmaya gönderiyoruz.
            }
        }
    }
}