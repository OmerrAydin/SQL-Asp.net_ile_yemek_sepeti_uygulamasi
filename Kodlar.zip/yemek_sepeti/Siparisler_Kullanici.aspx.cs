﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class Siparisler_Kullanici : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isCustomer"])) //Giris Yapan müşteri mi kontrol ediyoruz
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_SiparisleriGetir = new SqlCommand("up_SiparişleriGetirAliciyaGore @aliciKullaniciAdi = @PaliciKullaniciAdi", baglanti); //Alıcıya ait teslim edilmemiş tüm siparişleri getirir.
                sqlCommand_SiparisleriGetir.Parameters.AddWithValue("@PaliciKullaniciAdi", Convert.ToString(Session["Nickname"]));
                SqlDataReader okuyucu = sqlCommand_SiparisleriGetir.ExecuteReader();
                DataList1.DataSource = okuyucu;
                DataList1.DataBind(); //Verileri eşler.
                okuyucu.Close();

                SqlCommand sqlCommand_SiparisleriGetirTeslimOlan = new SqlCommand("up_TeslimEdilenSiparişleriGetirAliciyaGore @aliciKullaniciAdi = @PaliciKullaniciAdi", baglanti); //Alıcıya ait teslim edilmiş siparişleri getirir.
                sqlCommand_SiparisleriGetirTeslimOlan.Parameters.AddWithValue("@PaliciKullaniciAdi", Convert.ToString(Session["Nickname"]));
                SqlDataReader okuyucuTeslimOlan = sqlCommand_SiparisleriGetirTeslimOlan.ExecuteReader();
                DataList2.DataSource = okuyucuTeslimOlan;
                DataList2.DataBind(); //Verileri eşler.
                okuyucuTeslimOlan.Close();
                
                baglanti.Close();
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //Müşteri değilse giriş yapmaya gönderiyoruz.
            }
        }
    }
}