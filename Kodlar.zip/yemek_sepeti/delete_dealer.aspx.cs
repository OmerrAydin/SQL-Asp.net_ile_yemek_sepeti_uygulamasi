﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class delete_dealer : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        string kullanici_adi;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isAdmin"]) == true) //Giris Yapan admin mi kontrol ediyoruz
            {
                int silinecek_satici_id = Convert.ToInt32(Request.QueryString["ID"]); //Seçili satıcının idsi gelir

                SqlConnection baglanti = baglanti_cls.Baglan();
                SqlCommand sqlCommand_SaticiGetir = new SqlCommand("select Satici_KullaniciAdi from tbl_saticilar where Satici_ID = @Pid", baglanti);
                sqlCommand_SaticiGetir.Parameters.AddWithValue("@Pid", silinecek_satici_id);
                SqlDataReader okuyucu = sqlCommand_SaticiGetir.ExecuteReader();
                while (okuyucu.Read())
                {
                    kullanici_adi = okuyucu[0].ToString();
                }
                okuyucu.Close();

                SqlCommand sqlCommand_SiparisSil = new SqlCommand("delete from tbl_siparişler where Satici_KullaniciAdi = @PkullaniciAdi", baglanti);
                sqlCommand_SiparisSil.Parameters.AddWithValue("@PkullaniciAdi", kullanici_adi);
                sqlCommand_SiparisSil.ExecuteNonQuery();

                SqlCommand sqlCommand_YemekSil = new SqlCommand("delete from tbl_yemekler where Satici_KullaniciAdi = @PkullaniciAdi", baglanti);
                sqlCommand_YemekSil.Parameters.AddWithValue("@PkullaniciAdi", kullanici_adi);
                sqlCommand_YemekSil.ExecuteNonQuery();

                SqlCommand sqlCommand_MesajiSil = new SqlCommand("delete from tbl_saticilar where Satici_ID = @Pid", baglanti); //is si seçilen satıcıyı siler
                sqlCommand_MesajiSil.Parameters.AddWithValue("@Pid", silinecek_satici_id);
                sqlCommand_MesajiSil.ExecuteNonQuery();
                baglanti.Close();

                Response.Redirect("Admin_Satici_Guncelle.aspx"); //Satıcı güncelleme sayfasına geri döner
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //admin değilse giriş yapmaya gönderiyoruz.
            }
        }
    }
}