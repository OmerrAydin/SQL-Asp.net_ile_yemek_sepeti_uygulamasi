﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class dealer_meal_reject : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isDealer"]) == true) //Giris Yapan satıcı mı kontrol ediyoruz
            {
                int onaylanacak_siparis = Convert.ToInt32(Request.QueryString["ID"]); //Seçili siparişin idsi gelir

                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_SiparisOnayla = new SqlCommand("delete from tbl_siparişler where ID = @Pid", baglanti);//Siparişi siliyoruz.
                sqlCommand_SiparisOnayla.Parameters.AddWithValue("@Pid", onaylanacak_siparis);

                sqlCommand_SiparisOnayla.ExecuteNonQuery();
                baglanti.Close();

                Response.Redirect("Siparis_Onayla.aspx"); //Sipariş onaylama sayfasına geri dönüyoruz.
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //Satıcı değilse giriş yapmaya gönderiyoruz.
            }
        }
    }
}