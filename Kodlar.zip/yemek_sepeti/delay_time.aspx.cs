﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class delay_time : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        string siparis_zamani;
        string simdiki_zaman;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isCustomer"]) == true) //Giris Yapan müşteri mi kontrol ediyoruz
            {
                int guncellenecek_siparis = Convert.ToInt32(Request.QueryString["ID"]); //Seçili siparişin idsi gelir

                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz

                SqlCommand sqlCommand_ZamaniGetir = new SqlCommand("select Siparis_Zamani from tbl_siparişler where ID = @Pid", baglanti); //Sparişin verildiği tarihi çağırıyoruz.
                sqlCommand_ZamaniGetir.Parameters.AddWithValue("@Pid", guncellenecek_siparis);
                SqlDataReader okuyucu = sqlCommand_ZamaniGetir.ExecuteReader();
                while (okuyucu.Read())
                {
                    siparis_zamani = okuyucu[0].ToString(); //Tarihi kaydediyoruz.
                }
                okuyucu.Close();

                SqlCommand sqlCommand_SimdikiZamaniGetir = new SqlCommand("select getdate()", baglanti); //Şuanın tarihini çağırıyoruz.
                SqlDataReader okuyucu1 = sqlCommand_SimdikiZamaniGetir.ExecuteReader();
                while (okuyucu1.Read())
                {
                    simdiki_zaman = okuyucu1[0].ToString(); //Tarihi kaydediyoruz.
                }
                okuyucu1.Close();

                SqlCommand sqlCommand_ZamaniHesapla = new SqlCommand("select dbo.GecikmeSuresiHesapla(@Psiparis_tarih,@simdiki_tarih)", baglanti); //Gecikme süresini hesaplıyoruz.
                sqlCommand_ZamaniHesapla.Parameters.AddWithValue("@Psiparis_tarih",siparis_zamani);
                sqlCommand_ZamaniHesapla.Parameters.AddWithValue("@simdiki_tarih", simdiki_zaman);
                SqlDataReader okuyucu2 = sqlCommand_ZamaniHesapla.ExecuteReader();
                while (okuyucu2.Read())
                {
                    Label1.Text = okuyucu2[0].ToString(); //Sonucu label1 de yazdırıyoruz.
                }
                okuyucu2.Close();
                baglanti.Close();
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //Müşteri değilse giriş yapmaya gönderiyoruz.
            }
        }
    }
}