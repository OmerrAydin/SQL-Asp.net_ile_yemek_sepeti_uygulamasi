﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class Onay_Admin : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isAdmin"]) == true) //Giris Yapan admin mi kontrol ediyoruz
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_YemekList = new SqlCommand("up_YemeklerVeSaticilariniGetirOnayaGore @onay = @Ponay", baglanti); //Onaylanmamış yemekleri ve satıcılarını getiriyoruz.
                sqlCommand_YemekList.Parameters.AddWithValue("@Ponay", false);

                SqlDataReader okuyucu = sqlCommand_YemekList.ExecuteReader();
                DataList1.DataSource = okuyucu;
                DataList1.DataBind(); //Verileri eşliyoruz.
                okuyucu.Close();
                baglanti.Close();
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //admin değilse giris yapmaya yönlendirir.
            }
        }
    }
}