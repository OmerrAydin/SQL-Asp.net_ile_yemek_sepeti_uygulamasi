﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class admin_meal_reject : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isAdmin"]) == true) //Giris Yapan admin mi kontrol ediyoruz
            {
                int silinecek_yemek = Convert.ToInt32(Request.QueryString["ID"]); //Seçili yemeğin idsi gelir

                SqlConnection baglanti = baglanti_cls.Baglan();
                SqlCommand sqlCommand_YemekSil = new SqlCommand("delete from tbl_yemekler where Yemek_ID = @Pid", baglanti); //Yemek silinir.
                sqlCommand_YemekSil.Parameters.AddWithValue("@Pid", silinecek_yemek); //Silinecek yemeğin idsi gonderilir.

                sqlCommand_YemekSil.ExecuteNonQuery();
                baglanti.Close();

                Response.Redirect("Onay_Admin.aspx"); //Onay admin sayfasına geri dönülür.
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //admin değilse giris yapmaya yönlendirir. 
            }
            
        }
    }
}