﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class Admin_Kayit_Datalari : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isAdmin"]) == true) //Giris Yapan admin mi kontrol ediyoruz
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_DatalariGetir = new SqlCommand("select KullaniciKayitKaydi from tbl_kullanici_kayit_datalari", baglanti); //Admin data kayıtlarını getirir.

                SqlDataReader okuyucu = sqlCommand_DatalariGetir.ExecuteReader();
                DataList1.DataSource = okuyucu;
                DataList1.DataBind();
                okuyucu.Close();
                baglanti.Close();
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //admin değilse giris yapmaya yönlendirir.
            }
        }
    }
}