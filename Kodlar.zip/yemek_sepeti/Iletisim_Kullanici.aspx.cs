﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class Iletisim : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isCustomer"]) == true) //Giris Yapan müşteri mi kontrol ediyoruz
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_KullaniciAdiGetir = new SqlCommand("select Musteri_KullaniciAdi, Musteri_Mail from tbl_musteriler where Musteri_KullaniciAdi = @Pkullanici_adi", baglanti); //Müşteri mail ve kullanıcı adını çekiyoruz.

                sqlCommand_KullaniciAdiGetir.Parameters.AddWithValue("@Pkullanici_adi", Convert.ToString(Session["Nickname"]));

                SqlDataReader okuyucu = sqlCommand_KullaniciAdiGetir.ExecuteReader();
                while (okuyucu.Read())
                {
                    txt_nickname.Text = Convert.ToString(okuyucu[0]); //kullanıcı adını kaydediyoruz.
                    txt_mail.Text = Convert.ToString(okuyucu[1]); //Maili kaydediyoruz.
                }
                okuyucu.Close();
                baglanti.Close();
            }

            else
            {
                Response.Redirect("Giris_Yap.aspx"); //Müşteri değilse giriş yapmaya gönderiyoruz.
            }
            
        }

        protected void btn_msgGonder_Click(object sender, EventArgs e)
        {
            
            SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz

            SqlCommand sqlCommand_MesajGonder = new SqlCommand("insert into tbl_admin_iletisim (Gonderen_KullaniciAdi,Gonderen_Mail,Mesaj) values (@Pname,@Pmail,@Pmsg)", baglanti); //Mesajlar tablosuna mesajı kaydediyoruz.
            
            sqlCommand_MesajGonder.Parameters.AddWithValue("@Pname",txt_nickname.Text);
            sqlCommand_MesajGonder.Parameters.AddWithValue("@Pmail", txt_mail.Text);
            sqlCommand_MesajGonder.Parameters.AddWithValue("@Pmsg", txt_message.Text);
            
            sqlCommand_MesajGonder .ExecuteNonQuery();
            baglanti.Close();

        }
    }
}