﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class meat_follow_up_yoloCikti : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isDealer"]) == true) //Giris Yapan satıcı mı kontrol ediyoruz
            {
                int guncel_durum = Convert.ToInt32(Request.QueryString["ID"]); //Seçili siparişin idsi gelir
                SqlConnection baglanti = baglanti_cls.Baglan();
                SqlCommand sqlCommand_DurumGuncelle = new SqlCommand("update tbl_siparişler set Siparis_Durumu = 'Sipariş Yola Çıktı.' where ID=@Pid", baglanti); //Veritabanındaki sipariş durumunu Sipariş Yola Çıktı yapıyoruz.
                sqlCommand_DurumGuncelle.Parameters.AddWithValue("@Pid", guncel_durum);
                sqlCommand_DurumGuncelle.ExecuteNonQuery();
                baglanti.Close();
                Response.Redirect("Siparisler_Satici.aspx"); //Siparişler sayfasına geri dönüyoruz.
            }
        }
    }
}