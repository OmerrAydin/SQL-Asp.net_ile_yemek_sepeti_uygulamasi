﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class send_point : System.Web.UI.Page
    {
        string puan;
        string yemek_id;
        string ort_yemek_puan;
        string oy_veren_kişi_sayisi;
        string yemek_yorumu;
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["isCustomer"]) == true) //Giris Yapan satıcı mı kontrol ediyoruz
            {
                int siparis_id = Convert.ToInt32(Request.QueryString["ID"]); //Seçili siparişin idsi gelir
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_PuaniGetir = new SqlCommand("select Yemek_Puanı,Yemek_ID,Yemek_Yorumu from tbl_siparişler where ID = @Pid", baglanti); //Puan, id, yorumu getiriyoruz.
                sqlCommand_PuaniGetir.Parameters.AddWithValue("@Pid", siparis_id);
                SqlDataReader okuyucu = sqlCommand_PuaniGetir.ExecuteReader();
                while (okuyucu.Read())
                {//Verileri texte kaydediyoruz.
                    puan = okuyucu[0].ToString();
                    yemek_id = okuyucu[1].ToString();
                    yemek_yorumu = okuyucu[2].ToString();
                }
                okuyucu.Close();
                baglanti.Close();

                if (puan != "" || yemek_yorumu != "") //Puan veya yorum daha önce yapılmışsa siparişler sayfasına geri gönderiyoruz.
                {
                    Response.Redirect("Siparisler_Kullanici.aspx");
                }
            }
            else
            {
                Response.Redirect("Giris_Yap.aspx"); //Müşteri değilse giriş yapmaya gönderiyoruz.
            }
            

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int siparis_id = Convert.ToInt32(Request.QueryString["ID"]); //Seçili siparişin idsi gelir

            if (puan == "" && yemek_yorumu == "" && txt_puan.Text != "" && Convert.ToInt32(txt_puan.Text)<=10 && Convert.ToInt32(txt_puan.Text) >= 0) //Gerekli kısıtlamaları yapıyoruz.
            {
                SqlConnection baglanti = baglanti_cls.Baglan();
                SqlCommand sqlCommand_PuanVer = new SqlCommand("update tbl_siparişler set Yemek_Puanı = @Ppuan where ID = @Pid", baglanti); //Yemek puanını güncelliyoruz.
                sqlCommand_PuanVer.Parameters.AddWithValue("@Pid", siparis_id);
                sqlCommand_PuanVer.Parameters.AddWithValue("@Ppuan", Convert.ToInt32(txt_puan.Text));
                sqlCommand_PuanVer.ExecuteNonQuery();

                SqlCommand sqlCommand_YemekPuanHesapla = new SqlCommand("select sum(Yemek_Puanı)/count(Yemek_Puanı) as puan, count(Yemek_Puanı) as Oylayanlar from tbl_siparişler where Yemek_ID = @Pyemek_id", baglanti); //Yemeğin ortalama puanını ve oylayan kişi sayısını hesaplıyoruz.
                sqlCommand_YemekPuanHesapla.Parameters.AddWithValue("@Pyemek_id", yemek_id);
                SqlDataReader okuyucu = sqlCommand_YemekPuanHesapla.ExecuteReader();
                while(okuyucu.Read())
                {//Verileri değişkenlere kaydediyoruz.
                    ort_yemek_puan = okuyucu[0].ToString();
                    oy_veren_kişi_sayisi = okuyucu[1].ToString();
                }
                okuyucu.Close();

                SqlCommand sqlCommand_YemekPuanGonder = new SqlCommand("update tbl_yemekler set Yemek_Puanı = @Port_puan, Yemek_OylayanSayisi = @Port_kisi where Yemek_ID = @Pyemek_id", baglanti); //Puanlayan kişi ve ortalama puanı yemekler tablosuna kaydediyoruz.
                sqlCommand_YemekPuanGonder.Parameters.AddWithValue("@Port_puan", ort_yemek_puan);
                sqlCommand_YemekPuanGonder.Parameters.AddWithValue("@Port_kisi", oy_veren_kişi_sayisi);
                sqlCommand_YemekPuanGonder.Parameters.AddWithValue("@Pyemek_id", yemek_id);
                sqlCommand_YemekPuanGonder.ExecuteNonQuery();

                baglanti.Close();


            }
            if(puan == "" && yemek_yorumu == "" && txt_yorum.Text != "") //Değerler boş ise
            {
                SqlConnection baglanti = baglanti_cls.Baglan();
                SqlCommand sqlCommand_YorumYap = new SqlCommand("update tbl_siparişler set Yemek_Yorumu = @Pyorum where ID = @Pid", baglanti); //Yorumu tabloya ekliyoruz.
                sqlCommand_YorumYap.Parameters.AddWithValue("@Pid", siparis_id);
                sqlCommand_YorumYap.Parameters.AddWithValue("@Pyorum", txt_yorum.Text);
                sqlCommand_YorumYap.ExecuteNonQuery();
                baglanti.Close();
            }
            Response.Redirect("Siparisler_Kullanici.aspx"); //Siparişler sayfasına gönderiyoruz.
        }
    }
}