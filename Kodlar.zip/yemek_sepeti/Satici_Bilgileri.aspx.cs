﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using yemek_sepeti.classes;

namespace yemek_sepeti
{
    public partial class Satici_Bilgileri : System.Web.UI.Page
    {
        SQLConnection baglanti_cls = new SQLConnection(); //Sql bağlantısını içeren fonksiyonu oluşturuyoruz.
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false) //Sadece sayfa ilk yüklendiğinde çalışacak kısım.
            {
                if (Convert.ToBoolean(Session["isDealer"]) == true) //Giris Yapan satıcı mı kontrol ediyoruz
                {
                    SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                    SqlCommand sqlCommand_KaydiGetir = new SqlCommand("select Satici_KullaniciAdi,Satici_İsmi,Satici_Mail,Satici_Tel,Satici_Şehir,Satici_Sifre from tbl_saticilar where Satici_KullaniciAdi = @PsaticiNickname", baglanti); //Kullanıcı adına göre satıcının tüm bilgilerini getiriyoruz.
                    sqlCommand_KaydiGetir.Parameters.AddWithValue("@PsaticiNickname", Session["Nickname"].ToString());
                    SqlDataReader okuyucu = sqlCommand_KaydiGetir.ExecuteReader();
                    while (okuyucu.Read())
                    {//Gelen verileri textlere atıyoruz.
                        txt_nickname.Text = okuyucu[0].ToString();
                        txt_name.Text = okuyucu[1].ToString();
                        txt_mail.Text = okuyucu[2].ToString();
                        txt_tel.Text = okuyucu[3].ToString();
                        txt_sehir.Text = okuyucu[4].ToString();
                        txt_password.Text = okuyucu[5].ToString();
                    }
                    okuyucu.Close();
                    baglanti.Close();
                }
                else
                {
                    Response.Redirect("Giris_Yap.aspx"); //admin değilse giriş yapmaya gönderiyoruz.
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (txt_tel.Text != "" && txt_sehir.Text != "" && txt_password.Text != "") //Girdilerin doluluğunu kontrol ediyoruz.
            {
                SqlConnection baglanti = baglanti_cls.Baglan(); //Baglantiyi başlatıyoruz
                SqlCommand sqlCommand_KaydiGüncelle = new SqlCommand("update tbl_saticilar set Satici_Sifre = @Psifre, Satici_Tel=@Ptel, Satici_Şehir = @Psehir where Satici_KullaniciAdi = @PsaticiNickname", baglanti); //Kullanıcı bilgilerini güncelliyoruz.
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@Psifre", txt_password.Text);
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@Ptel", txt_tel.Text);
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@Psehir", txt_sehir.Text);
                sqlCommand_KaydiGüncelle.Parameters.AddWithValue("@PsaticiNickname", Session["Nickname"].ToString());
                sqlCommand_KaydiGüncelle.ExecuteNonQuery();
                baglanti.Close();
                Response.Write("<script>alert('Güncelleme Başarılı');</script>"); //Ekrana başarılı yazdırıyoruz.
            }
            else
            {
                Response.Write("<script>alert('Eksik Veri Girişi Yaptınız');</script>"); //Ekrana veriler eksik yazdırıyoruz.
            }
        }
    }
}